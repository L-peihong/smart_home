#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "s1.h"
#include "s2.h"
#include "s7.h"
#include "s8.h"
#include "e1.h"
#include "e2.h"
#include "i2c.h"
#include "i2c_probe.h"

// 教师驱动中定义的全局变量
extern int key_idx;
extern int led_idx;
extern int tube_idx;
extern int bright_idx;
extern int human_idx;
extern int sht_idx;
extern s1_key_process *s1_key;

// ========== 全局状态变量 ==========
int fan_off = 0;					   // 风扇开关: 0关闭, 1开启
int lightness = 50;					   // E1亮度 (0-100)
int dang[] = {0, 20, 40, 60, 80, 100}; // 风扇档位
int dang_idx = 0;					   // 当前档位索引
int mode_display = 1;				   // 显示模式: 0关闭, 1温度, 2湿度, 3光照
int mode_fan = 0;					   // 风扇模式: 0手动, 1自动
int mode_background = 0;			   // 场景模式 (0办公,1学习,2睡眠,3娱乐)
int mode_set = 0;					   // 设置模式: 0普通, 1设置
int temperature_set = 28;			   // 温度阈值(℃)
int humidity_set = 60;				   // 湿度阈值(%)
int light_set = 500;				   // 光照阈值(lx)
int voice_mode = 0;					   // 语音模式开关
int sleep_time = 1;					   // 休眠等待时间(分钟): 1/3/5/10

// 全局环境数据结构
typedef struct
{
	float temperature;
	float humidity;
	float light_intensity;
	int human_detected;
	time_t timestamp;
} env_data_t;

env_data_t env; // 全局变量

// ========== 函数声明 ==========
void print_system_status(void);
void update_e1_display(int fd, i2c_probe_target *list);
void update_e1_led(int fd, i2c_probe_target *list);
void smart_control(int fd, i2c_probe_target *list);
void handle_key_event(int fd, i2c_probe_target *list, int dev_idx, int key_num);

// ========== 函数实现 ==========
void print_system_status(void)
{
	printf("\n========== 系统状态 ==========\n");
	printf("温度: %.1f ℃  湿度: %.1f %%  光照: %.0f lx\n",
		   env.temperature, env.humidity, env.light_intensity);
	printf("人体: %s  风扇: %s (档位: %d%%)  亮度: %d%%\n",
		   env.human_detected ? "有人" : "无人",
		   fan_off ? "开启" : "关闭", dang[dang_idx], lightness);
	printf("显示模式: ");
	switch (mode_display)
	{
	case 0:
		printf("关闭");
		break;
	case 1:
		printf("温度");
		break;
	case 2:
		printf("湿度");
		break;
	case 3:
		printf("光照");
		break;
	}
	printf("  场景模式: %d  设置模式: %s\n", mode_background, mode_set ? "开启" : "关闭");
	printf("阈值: 温度%d℃ 湿度%d%% 光照%dlx  休眠时间:%d分钟\n",
		   temperature_set, humidity_set, light_set, sleep_time);
	printf("==============================\n\n");
}

// 更新E1数码管显示
void update_e1_display(int fd, i2c_probe_target *list)
{
	if (tube_idx < 0 || mode_display == 0)
	{
		if (tube_idx >= 0)
			e1_digital_display_off_all(fd, list);
		return;
	}
	for (int i = 0; i < list[tube_idx].detected_count; i++)
	{
		unsigned char addr = list[tube_idx].detected_addrs[i];
		int val;
		if (mode_display == 1)
		{ // 温度
			val = (int)(env.temperature);
			if (val < 0)
			{
				e1_digital_bit_display_char(fd, addr, 0, '-');
				val = -val;
			}
			else
			{
				e1_digital_bit_display_char(fd, addr, 0, ' ');
			}
			e1_digital_display(fd, addr,
							   val / 1000, (val % 1000) / 100,
							   (val % 100) / 10, val % 10);
		}
		else if (mode_display == 2)
		{ // 湿度
			val = (int)(env.humidity);
			e1_digital_display(fd, addr,
							   val / 1000, (val % 1000) / 100,
							   (val % 100) / 10, val % 10);
		}
		else
		{ // 光照
			val = (int)env.light_intensity;
			if (val > 9999)
				val = 9999;
			e1_digital_display(fd, addr,
							   val / 1000, (val % 1000) / 100,
							   (val % 100) / 10, val % 10);
		}
	}
}

// 更新E1 RGB指示灯颜色
void update_e1_led(int fd, i2c_probe_target *list)
{
	if (led_idx < 0)
		return;
	e1_led_color_t color = E1_COLOR_GREEN;
	if (!env.human_detected)
	{
		color = E1_COLOR_BLUE; // 无人时蓝色(休眠)
	}
	else if (env.temperature > temperature_set + 3 ||
			 env.humidity > humidity_set + 20)
	{
		color = E1_COLOR_RED; // 异常红色
	}
	else if (env.temperature > temperature_set ||
			 env.humidity > humidity_set)
	{
		color = E1_COLOR_YELLOW; // 一般黄色
	}
	else
	{
		color = E1_COLOR_GREEN; // 舒适绿色
	}
	e1_led_ctrl_all(fd, list, color, lightness);
}

// 智能联动控制
void smart_control(int fd, i2c_probe_target *list)
{
	// 自动风扇控制
	if (mode_fan == 1)
	{
		if (env.temperature > 28)
		{
			if (!fan_off)
			{
				fan_off = 1;
				printf("[自动] 温度高(%.1f℃)，开启风扇\n", env.temperature);
			}
			if (env.temperature > 32)
				dang_idx = 4; // 高档
			else if (env.temperature > 30)
				dang_idx = 3; // 中档
			else
				dang_idx = 2; // 低档
			e2_speed_control_all(fd, list, dang[dang_idx]);
		}
		else if (env.temperature < 25 && fan_off)
		{
			e2_speed_control_all(fd, list, 0);
			fan_off = 0;
			printf("[自动] 温度适宜(%.1f℃)，关闭风扇\n", env.temperature);
		}
	}
	// 自动调节E1亮度(基于光照)
	if (env.light_intensity < 100)
	{
		lightness = 20;
	}
	else if (env.light_intensity > 1000)
	{
		lightness = 100;
	}
	else
	{
		lightness = 20 + (int)((env.light_intensity - 100) * 80 / 900);
	}
}

// 按键事件处理（长按/短按）
void handle_key_event(int fd, i2c_probe_target *list, int dev_idx, int key_num)
{
	if (key_idx < 0)
		return;
	// 长按
	if (s1_key[dev_idx].SW_long[key_num])
	{
		s1_key[dev_idx].SW_long[key_num] = false;
		printf("[长按] 按键 %d\n", key_num);
		switch (key_num)
		{
		case SW1:
			mode_set = !mode_set;
			printf("设置模式: %s\n", mode_set ? "开启" : "关闭");
			break;
		case SW2:
			voice_mode = !voice_mode;
			printf("语音控制: %s\n", voice_mode ? "开启" : "关闭");
			break;
		case SW3: // 休眠时间+
			if (sleep_time == 1)
				sleep_time = 3;
			else if (sleep_time == 3)
				sleep_time = 5;
			else if (sleep_time == 5)
				sleep_time = 10;
			printf("休眠时间: %d 分钟\n", sleep_time);
			break;
		case SW4: // 休眠时间-
			if (sleep_time == 10)
				sleep_time = 5;
			else if (sleep_time == 5)
				sleep_time = 3;
			else if (sleep_time == 3)
				sleep_time = 1;
			printf("休眠时间: %d 分钟\n", sleep_time);
			break;
		case SW5:
			temperature_set++;
			printf("温度阈值: %d ℃\n", temperature_set);
			break;
		case SW6:
			temperature_set--;
			printf("温度阈值: %d ℃\n", temperature_set);
			break;
		case SW7:
			humidity_set++;
			printf("湿度阈值: %d %%\n", humidity_set);
			break;
		case SW8:
			humidity_set--;
			printf("湿度阈值: %d %%\n", humidity_set);
			break;
		case SW9:
			light_set += 50;
			printf("光照阈值: %d lx\n", light_set);
			break;
		case SWA:
			light_set = (light_set >= 50) ? light_set - 50 : 0;
			printf("光照阈值: %d lx\n", light_set);
			break;
		case SWC:
			break;
		}
	}
	// 短按
	if (s1_key[dev_idx].SW_short[key_num])
	{
		s1_key[dev_idx].SW_short[key_num] = false;
		printf("[短按] 按键 %d\n", key_num);
		switch (key_num)
		{
		case SW1: // 风扇开/关
			if (fan_off)
			{
				e2_speed_control_all(fd, list, 0);
				fan_off = 0;
				printf("风扇关闭\n");
			}
			else
			{
				if (dang_idx == 0)
					dang_idx = 1; // 默认20%
				e2_speed_control_all(fd, list, dang[dang_idx]);
				fan_off = 1;
				printf("风扇开启 (档位: %d%%)\n", dang[dang_idx]);
			}
			break;
		case SW2: // 风扇档位切换(低->中->高->自动)
			if (mode_fan == 1)
			{
				mode_fan = 0;
				printf("风扇模式: 手动\n");
			}
			else
			{
				dang_idx = (dang_idx + 1) % 6;
				if (fan_off)
					e2_speed_control_all(fd, list, dang[dang_idx]);
				printf("风扇档位: %d%%\n", dang[dang_idx]);
			}
			break;
		case SW3: // E1显示模式切换
			mode_display = (mode_display + 1) % 4;
			printf("0为关闭,1为显示温度,2为显示湿度,3为显示光照\n");
			printf("显示模式: %d\n", mode_display);
			break;
		case SW4: // 场景模式切换
			mode_background = (mode_background + 1) % 4;
			printf("0为办公模式,1为学习模式,2为睡眠模式,3为娱乐模式\n");
			printf("场景模式: %d\n", mode_background);
			break;
		case SW5: // 亮度+
			lightness += 10;
			if (lightness > 100)
				lightness = 100;
			printf("亮度: %d%%\n", lightness);
			break;
		case SW6: // 亮度-
			lightness -= 10;
			if (lightness < 0)
				lightness = 0;
			printf("亮度: %d%%\n", lightness);
			break;
		case SW7: // 风扇转速+
			if (fan_off && dang_idx < 5)
			{
				dang_idx++;
				e2_speed_control_all(fd, list, dang[dang_idx]);
				printf("风扇档位: %d%%\n", dang[dang_idx]);
			}
			break;
		case SW8: // 风扇转速-
			if (fan_off && dang_idx > 0)
			{
				dang_idx--;
				e2_speed_control_all(fd, list, dang[dang_idx]);
				printf("风扇档位: %d%%\n", dang[dang_idx]);
			}
			break;
		case SW9: // 语音播报当前环境状态
			printf("[语音播报] 当前温度%.1f度，湿度%.1f%%，光照%.0flx\n",
				   env.temperature, env.humidity, env.light_intensity);
			break;
		case SWA: // 屏幕亮/灭
			if (mode_display == 0)
				mode_display = 1;
			else
				mode_display = 0;
			printf("屏幕%s\n", mode_display ? "亮起" : "熄灭");
			break;
		case SWC: // 系统重启
			printf("系统重启...\n");
			// 可调用 reboot 或 exit
			break;
		}
	}
}

// ========== 主函数 ==========
int main()
{
	// 为 I2C 探测列表分配可修改的副本
	size_t list_size = sizeof(i2c_probe_target) * I2C_PROBE_LIST_LEN;
	i2c_probe_target *list = (i2c_probe_target *)malloc(list_size);
	if (!list)
	{
		perror("malloc failed");
		return -1;
	}
	memcpy(list, I2C_PROBE_LIST, list_size);

	printf("========================================\n");
	printf("  桌面智能管家系统 - 第一周任务\n");
	printf("  传感器与执行器驱动测试\n");
	printf("========================================\n\n");

	// 1. 探测所有I2C设备
	printf("[1/6] I2C设备探测中...\n");
	i2c_probe(list, I2C_PROBE_LIST_LEN);
	printf("探测完成\n\n");

	// 2. 查找各模块（若缺失会exit，请确保硬件齐全）
	printf("[2/6] 查找各模块...\n");
	I2c_s1_find(list);
	I2c_s2_find(list);
	I2c_s7_find(list);
	I2c_s8_find(list);
	I2c_e1_led_find(list);
	I2c_e1_tube_find(list);
	I2c_e2_find(list);
	printf("所有模块已找到\n\n");

	// 3. 打开I2C设备（使用S1所在总线）
	int fd = I2c_open(list[key_idx].path);
	if (fd < 0)
	{
		perror("打开I2C设备失败");
		free(list);
		return -1;
	}
	printf("I2C设备已打开，fd=%d\n\n", fd);

	// 4. 初始化各模块
	printf("[3/6] 初始化S1键盘...\n");
	I2c_s1_init_all(fd, list);
	printf("[4/6] 初始化E1数码管与RGB灯...\n");
	I2c_e1_tube_init_all(fd, list);
	I2c_e1_led_init_all(fd, list);
	printf("[5/6] 初始化E2风扇...\n");
	I2c_e2_init_all(fd, list);
	printf("[6/6] 初始化传感器...\n");
	I2c_s2_init_all(fd, list);
	I2c_s7_init_all(fd, list);
	// S8无需显式初始化
	printf("\n所有模块初始化完成！开始运行...\n\n");

	// 环境数据初始值
	memset(&env, 0, sizeof(env));
	env.temperature = 25.0;
	env.humidity = 50.0;
	env.light_intensity = 300.0;
	env.human_detected = 1;

	int loop_cnt = 0;
	int sht_delay = 0; // 用于控制SHT3x读取频率(每2秒一次)

	while (1)
	{
		loop_cnt++;
		sht_delay++;

		// 采集S8温湿度(每2秒一次，避免I2C过载)
		if (sht_delay >= 40)
		{ // 50ms * 40 = 2秒
			sht_delay = 0;
			if (sht_idx >= 0 && list[sht_idx].detected_count > 0)
			{
				s8_para sht = read_sht3x(fd, list[sht_idx].detected_addrs[0]);
				if (sht.temperature >= -45 && sht.temperature <= 125)
					env.temperature = sht.temperature;
				if (sht.humidity >= 0 && sht.humidity <= 100)
					env.humidity = sht.humidity;
			}
		}
		// 采集S2光照
		if (bright_idx >= 0 && list[bright_idx].detected_count > 0)
		{
			float lux = s2_read_bh1750_value(fd, list[bright_idx].detected_addrs[0]);
			if (lux >= 0 && lux < 100000)
				env.light_intensity = lux;
		}
		// 采集S7人体
		if (human_idx >= 0 && list[human_idx].detected_count > 0)
		{
			env.human_detected = I2c_human_detected(fd, list[human_idx].detected_addrs[0]);
		}
		env.timestamp = time(NULL);

		// 智能联动控制
		// smart_control(fd, list);
		// 更新E1显示和LED
		update_e1_display(fd, list);
		update_e1_led(fd, list);

		// 按键处理（关键！）
		if (key_idx >= 0)
		{
			for (int i = 0; i < list[key_idx].detected_count; i++)
			{
				// 扫描按键状态（教师提供的函数）
				process_keys(fd, list[key_idx].detected_addrs[i], list);
				// 处理所有12个按键的事件
				for (int k = 1; k <= 12; k++)
				{
					handle_key_event(fd, list, i, k);
				}
			}
		}

		// 每100次循环(约5秒)打印一次状态
		if (loop_cnt % 100 == 0)
		{
			print_system_status();
		}

		// 提高响应速度：50ms 循环一次
		usleep(50000); // 50ms
	}

	I2c_close(fd);
	free(list);
	return 0;
}
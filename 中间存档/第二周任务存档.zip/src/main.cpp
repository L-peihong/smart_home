#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "s1.h"
#include "s2.h"
#include "s7.h"
#include "s8.h"
#include "e1.h"
#include "e2.h"
#include "i2c.h"
#include "i2c_probe.h"
#include <pthread.h>
#include <sys/reboot.h>

extern int key_idx;
extern int led_idx;
extern int tube_idx;
extern int bright_idx;
extern int human_idx;
extern int sht_idx;
extern s1_key_process *s1_key;

// ========== 全局状态变量 ==========
int fan_off = 0;					   // 风扇开关: 0关闭, 1开启
int lightness = 50;					   // E1亮度 (0-100)
int dang[] = {0, 20, 40, 60, 80, 100}; // 风扇档位
int dang_idx = 0;					   // 当前档位索引
int mode_display = 1;				   // 显示模式: 0关闭, 1温度, 2湿度, 3光照
int mode_fan = 0;					   // 风扇模式: 0手动, 1自动
int mode_background = 0;			   // 场景模式 (0办公,1学习,2睡眠,3娱乐)
int mode_set = 0;					   // 设置模式: 0普通, 1设置
int temperature_set = 28;			   // 温度阈值(℃)
int humidity_set = 60;				   // 湿度阈值(%)
int light_set = 500;				   // 光照阈值(lx)
int voice_mode = 0;					   // 语音模式开关
int sleep_time = 1;					   // 休眠等待时间(分钟): 1/3/5/10
int light_mode = 0; 				   // 0为手动模式 1为自动模式

int fan_was_on_before_idle = 0;   // 记录进入待机前的风扇开关状态
int fan_dang_idx_before_idle = 0; // 记录进入待机前的风扇档位索引

// 全局环境数据结构
typedef struct
{
	float temperature;
	float humidity;
	float light_intensity;
	int human_detected;
	time_t timestamp;
} env_data_t;

env_data_t env; // 全局变量

int e5_idle = 0;		  // E5 待机状态
int no_human_seconds = 0; // 无人计时
int e1_cycle_tick = 0;	  // E1 自动切换计数
int record_seconds = 3;	  // 录音时长
float env_hist_temp[60] = {0};
float env_hist_hum[60] = {0};
float env_hist_lux[60] = {0};
int env_hist_count = 0;
int env_hist_pos = 0;
char alert_message[128] = "";
int e5_scene = 0;
int e5_voice_on = 1;

// Week2: audio thread control
static pthread_t audio_thread_id;
static pthread_mutex_t audio_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t audio_cond = PTHREAD_COND_INITIALIZER;
static char audio_path[512] = {0};
static int audio_play_requested = 0;

// 简单的录音请求（不队列化，直接 spawn）
void request_record_audio(const char *outpath, int seconds)
{
	if (!outpath)
		return;
	char cmd[1024];
	// 使用 tinycap 进行录音（参考 S3_README）
	snprintf(cmd, sizeof(cmd), "tinycap %s -D 0 -d 0 -t %d -b 16 -r 16000 &", outpath, seconds);
	printf("[S3] 开始录音: %s (%ds)\n", outpath, seconds);
	system(cmd);
}

// 请求播放音频（非阻塞，通过后台线程执行）
void request_play_audio(const char *path)
{
	if (!path)
		return;
	pthread_mutex_lock(&audio_mutex);
	strncpy(audio_path, path, sizeof(audio_path) - 1);
	audio_play_requested = 1;
	pthread_cond_signal(&audio_cond);
	pthread_mutex_unlock(&audio_mutex);
}

// 后台音频线程：等待播放请求并调用 tinyplay
static void *audio_thread(void *arg)
{
	(void)arg;
	for (;;)
	{
		pthread_mutex_lock(&audio_mutex);
		while (!audio_play_requested)
			pthread_cond_wait(&audio_cond, &audio_mutex);

		char localpath[512] = {0};
		strncpy(localpath, audio_path, sizeof(localpath) - 1);
		audio_play_requested = 0;
		pthread_mutex_unlock(&audio_mutex);

		if (localpath[0])
		{
			char cmd[1024];
			snprintf(cmd, sizeof(cmd), "tinyplay -D 0 -d 1 -r 16000 %s", localpath);
			printf("[E4] 播放音频: %s\n", localpath);
			system(cmd);
			printf("[E4] 播放完成: %s\n", localpath);
		}
	}
	return NULL;
}

// 文本到语音：尝试本地 TTS 命令生成 WAV 并播放
void tts_speak(const char *text)
{
	if (!text || text[0] == '\0')
		return;
	const char *out = "/userdata/tts_announce.wav";
	char cmd[1024];

	// 优先使用 pico2wave（中文质量好，轻量）
	if (access("/usr/bin/pico2wave", X_OK) == 0)
	{
		snprintf(cmd, sizeof(cmd), "/usr/bin/pico2wave -l=zh-CN -w=%s \"%s\"", out, text);
		printf("[TTS] 使用 pico2wave 合成: %s\n", cmd);
		system(cmd);
		request_play_audio(out);
		return;
	}

	// 其次尝试 espeak-ng
	if (access("/usr/bin/espeak-ng", X_OK) == 0)
	{
		snprintf(cmd, sizeof(cmd), "/usr/bin/espeak-ng -v zh -w %s \"%s\"", out, text);
		printf("[TTS] 使用 espeak-ng 合成: %s\n", cmd);
		system(cmd);
		request_play_audio(out);
		return;
	}

	// 再尝试传统 espeak
	if (access("/usr/bin/espeak", X_OK) == 0)
	{
		snprintf(cmd, sizeof(cmd), "/usr/bin/espeak -v zh -w %s \"%s\"", out, text);
		printf("[TTS] 使用 espeak 合成: %s\n", cmd);
		system(cmd);
		request_play_audio(out);
		return;
	}

	// 最后尝试 flite
	if (access("/usr/bin/flite", X_OK) == 0)
	{
		snprintf(cmd, sizeof(cmd), "/usr/bin/flite -t \"%s\" -o %s", text, out);
		printf("[TTS] 使用 flite 合成: %s\n", cmd);
		system(cmd);
		request_play_audio(out);
		return;
	}

	// 回退：若都不可用，则打印文本
	printf("[TTS] 无可用 TTS 引擎，本地输出文本：%s\n", text);
}

// ========== 函数声明 ==========
void print_system_status(void);
void update_e1_display(int fd, i2c_probe_target *list);
void update_e1_led(int fd, i2c_probe_target *list);
void smart_control(int fd, i2c_probe_target *list);
void handle_key_event(int fd, i2c_probe_target *list, int dev_idx, int key_num);
// Week2: audio / touchscreen / mic helpers
void update_e5_display(int fd, i2c_probe_target *list);
void request_play_audio(const char *path);
void request_record_audio(const char *outpath, int seconds);
void tts_speak(const char *text);
void system_reboot(void);

// ========== 函数实现 ==========
void print_system_status(void)
{
	printf("\n========== 系统状态 ==========\n");
	printf("温度: %.1f ℃  湿度: %.1f %%  光照: %.0f lx\n",
		   env.temperature, env.humidity, env.light_intensity);
	printf("人体: %s  风扇: %s (档位: %d%%)  亮度: %d%%\n",
		   env.human_detected ? "有人" : "无人",
		   fan_off ? "开启" : "关闭", dang[dang_idx], lightness);
	printf("显示模式: ");
	switch (mode_display)
	{
	case 0:
		printf("关闭");
		break;
	case 1:
		printf("温度");
		break;
	case 2:
		printf("湿度");
		break;
	case 3:
		printf("光照");
		break;
	}
	printf("  场景模式: %d  设置模式: %s\n", mode_background, mode_set ? "开启" : "关闭");
	printf("阈值: 温度%d℃ 湿度%d%% 光照%dlx  休眠时间:%d分钟\n",
		   temperature_set, humidity_set, light_set, sleep_time);
	printf("==============================\n\n");
}

// 更新E1数码管显示
void update_e1_display(int fd, i2c_probe_target *list)
{
	if (tube_idx < 0 || mode_display == 0 || !env.human_detected)
	{
		mode_display=0;
		if (tube_idx >= 0)
			e1_digital_display_off_all(fd, list);
		return;
	}
	for (int i = 0; i < list[tube_idx].detected_count; i++)
	{
		unsigned char addr = list[tube_idx].detected_addrs[i];
		int val;
		if (mode_display == 1)
		{ // 温度
			val = (int)(env.temperature);
			if (val < 0)
			{
				e1_digital_bit_display_char(fd, addr, 0, '-');
				val = -val;
			}
			else
			{
				e1_digital_bit_display_char(fd, addr, 0, ' ');
			}
			e1_digital_display(fd, addr,
							   val / 1000, (val % 1000) / 100,
							   (val % 100) / 10, val % 10);
		}
		else if (mode_display == 2)
		{ // 湿度
			val = (int)(env.humidity);
			e1_digital_display(fd, addr,
							   val / 1000, (val % 1000) / 100,
							   (val % 100) / 10, val % 10);
		}
		else
		{ // 光照
			val = (int)env.light_intensity;
			if (val > 9999)
				val = 9999;
			e1_digital_display(fd, addr,
							   val / 1000, (val % 1000) / 100,
							   (val % 100) / 10, val % 10);
		}
	}
}

// 更新E1 RGB指示灯颜色
void update_e1_led(int fd, i2c_probe_target *list)
{
	if (led_idx < 0)
		return;
	e1_led_color_t color = E1_COLOR_GREEN;
	if (!env.human_detected)
	{
		color = E1_COLOR_BLUE; // 无人时蓝色(休眠)
	}
	else if (env.temperature > temperature_set + 3 ||
			 env.humidity > humidity_set + 20)
	{
		color = E1_COLOR_RED; // 异常红色
	}
	else if (env.temperature > temperature_set ||
			 env.humidity > humidity_set)
	{
		color = E1_COLOR_YELLOW; // 一般黄色
	}
	else
	{
		color = E1_COLOR_GREEN; // 舒适绿色
	}
	e1_led_ctrl_all(fd, list, color, lightness);
}

// 将 E1 的摘要信息同步到 E5（触控屏）显示
void update_e5_display(int fd, i2c_probe_target *list)
{
	// 更新历史曲线数据
	if (env_hist_count < 60)
		env_hist_count++;
	env_hist_temp[env_hist_pos] = env.temperature;
	env_hist_hum[env_hist_pos] = env.humidity;
	env_hist_lux[env_hist_pos] = env.light_intensity;
	env_hist_pos = (env_hist_pos + 1) % 60;

	// 无人待机逻辑
	if (!env.human_detected)
	{
		if (fan_off)
			{
				e2_speed_control_all(fd, list, 0);
				fan_off = 0;
			}
		printf("[无人待机] 进入待机，E1熄屏，风扇已关闭\n");
		// if (++no_human_seconds >= (sleep_time * 60 * 20))
		// {
		// 	if (!e5_idle)
		// 	{
		// 		e5_idle = 1;
		// 		mode_display = 0;
				
		// 		// 记录无人前的风扇状态（仅第一次进入待机时）
		// 		fan_was_on_before_idle = fan_off;
		// 		fan_dang_idx_before_idle = dang_idx;
				
		// 		// 强制关闭风扇
		// 		if (fan_off)
		// 		{
		// 			e2_speed_control_all(fd, list, 0);
		// 			fan_off = 0;
		// 		}
		// 		printf("[无人待机] 进入待机，E1熄屏，风扇已关闭\n");
		// 	}
		// }
	}
	else
	{
		no_human_seconds = 0;
		if (e5_idle)
		{
			e5_idle = 0;
			mode_display = 1;
			
			// 恢复风扇状态
			if (fan_was_on_before_idle)
			{
				dang_idx = fan_dang_idx_before_idle;
				e2_speed_control_all(fd, list, dang[dang_idx]);
				fan_off = 1;
				printf("[有人唤醒] 恢复风扇档位 %d%%\n", dang[dang_idx]);
			}
			else
			{
				printf("[有人唤醒] 风扇保持关闭\n");
			}
		}
	}


	// E1 自动循环显示（每3秒切换一次温度/湿度/光照）
	if (!mode_set && !e5_idle)
	{
		e1_cycle_tick++;
		if (e1_cycle_tick >= 60)
		{
			e1_cycle_tick = 0;
			mode_display = (mode_display == 0) ? 1 : ((mode_display % 3) + 1);
		}
	}

	// 检查阈值告警
	alert_message[0] = '\0';
	if (env.temperature > temperature_set || env.humidity > humidity_set || env.light_intensity > light_set)
	{
		alert_message[0] = '\0';
		snprintf(alert_message, sizeof(alert_message), "环境异常: 温%.1f℃ 湿%.1f%% 光%.0flx", env.temperature, env.humidity, env.light_intensity);
	}
	else
	{
		snprintf(alert_message, sizeof(alert_message), "环境正常");
	}

	// 写 e5 状态 JSON
	FILE *f = fopen("./web/e5_status.json", "w");
	if (f)
	{
		int start = (env_hist_pos + 60 - env_hist_count) % 60;
		fprintf(f, "{\n");
		fprintf(f, "  \"temperature\": %.1f,\n", env.temperature);
		fprintf(f, "  \"humidity\": %.1f,\n", env.humidity);
		fprintf(f, "  \"light\": %.1f,\n", env.light_intensity);
		fprintf(f, "  \"human\": %d,\n", env.human_detected);
		fprintf(f, "  \"fan_on\": %d,\n", fan_off);
		fprintf(f, "  \"fan_level\": %d,\n", dang[dang_idx]);
		fprintf(f, "  \"temperature_set\": %d,\n", temperature_set);
		fprintf(f, "  \"humidity_set\": %d,\n", humidity_set);
		fprintf(f, "  \"light_set\": %d,\n", light_set);
		fprintf(f, "  \"scene\": %d,\n", mode_background);
		fprintf(f, "  \"voice_on\": %d,\n", e5_voice_on);
		fprintf(f, "  \"sleep_time\": %d,\n", sleep_time);
		fprintf(f, "  \"display_mode\": %d,\n", mode_display);   
		fprintf(f, "  \"brightness\": %d,\n", lightness);        
		fprintf(f, "  \"fan_mode\": %d,\n", mode_fan);           
		fprintf(f, "  \"light_mode\": %d,\n", light_mode);
		fprintf(f, "  \"idle\": %d,\n", e5_idle);
		fprintf(f, "  \"alert\": \"%s\",\n", alert_message);
		fprintf(f, "  \"history\": {\n");
		fprintf(f, "    \"temp\": [");

		for (int i = 0, idx = start; i < env_hist_count; i++, idx = (idx + 1) % 60)
		{
			fprintf(f, "%s%.1f", i ? ", " : "", env_hist_temp[idx]);
		}
		fprintf(f, "],\n");
		fprintf(f, "    \"hum\": [");
		for (int i = 0, idx = start; i < env_hist_count; i++, idx = (idx + 1) % 60)
		{
			fprintf(f, "%s%.1f", i ? ", " : "", env_hist_hum[idx]);
		}
		fprintf(f, "],\n");
		fprintf(f, "    \"lux\": [");
		for (int i = 0, idx = start; i < env_hist_count; i++, idx = (idx + 1) % 60)
		{
			fprintf(f, "%s%.1f", i ? ", " : "", env_hist_lux[idx]);
		}
		fprintf(f, "]\n");
		fprintf(f, "  }\n");
		fprintf(f, "}\n");
		fclose(f);
	}

	// 旧版兼容展示文本
	char buf[512];
	snprintf(buf, sizeof(buf), "温度:%.1fC 湿度:%.1f%% 光照:%.0flx 人体:%s 风扇:%s 场景:%d %s\n",
			 env.temperature, env.humidity, env.light_intensity,
			 env.human_detected ? "有人" : "无人",
			 fan_off ? "开" : "关",
			 mode_background,
			 e5_idle ? "[待机]" : alert_message);
	FILE *f2 = fopen("./web/e5_ui.txt", "w");
	if (f2)
	{
		fprintf(f2, "%s", buf);
		fclose(f2);
	}
}

void process_e5_command(int fd, i2c_probe_target *list)
{
	FILE *fcmd = fopen("./web/e5_command.txt", "r");
	if (!fcmd)
		return;

	char line[256];
	if (fgets(line, sizeof(line), fcmd))
	{
		char *p = strchr(line, '\n');
		if (p)
			*p = '\0';

		char *tok = strtok(line, ":");
		if (!tok)
		{
			fclose(fcmd);
			remove("./web/e5_command.txt");
			return;
		}

		char *action = strtok(NULL, ":");
		char *value = strtok(NULL, ":");

		if (strcmp(tok, "fan") == 0 && action)
		{
			if (strcmp(action, "on") == 0)
			{
				int sp = value ? atoi(value) : dang[dang_idx];
				int idx = 0;
				int bestdiff = 10000;
				for (int i = 0; i < 6; i++)
				{
					int diff = abs(dang[i] - sp);
					if (diff < bestdiff)
					{
						bestdiff = diff;
						idx = i;
					}
				}
				dang_idx = idx;
				e2_speed_control_all(fd, list, dang[dang_idx]);
				fan_off = 1;
				printf("[E5] 风扇 开 (档位:%d%%)\n", dang[dang_idx]);
			}
			else if (strcmp(action, "off") == 0)
			{
				e2_speed_control_all(fd, list, 0);
				fan_off = 0;
				printf("[E5] 风扇 关\n");
			}
			else if (strcmp(action, "set") == 0)
			{
				int sp = value ? atoi(value) : dang[dang_idx];
				int idx = 0;
				int bestdiff = 10000;
				for (int i = 0; i < 6; i++)
				{
					int diff = abs(dang[i] - sp);
					if (diff < bestdiff)
					{
						bestdiff = diff;
						idx = i;
					}
				}
				dang_idx = idx;
				if (fan_off)
					e2_speed_control_all(fd, list, dang[dang_idx]);
				printf("[E5] 风扇 档位设置 %d%%\n", dang[dang_idx]);
			}
		}
		else if (strcmp(tok, "scene") == 0 && action)
		{
			mode_background = atoi(action);
			printf("[E5] 场景设置 %d\n", mode_background);
		}
		else if (strcmp(tok, "voice") == 0 && action)
		{
			e5_voice_on = (strcmp(action, "on") == 0);
			printf("[E5] 语音播报 %s\n", e5_voice_on ? "开启" : "关闭");
		}
		else if (strcmp(tok, "threshold") == 0 && action && value)
		{
			if (strcmp(action, "temp") == 0)
				temperature_set = atoi(value);
			else if (strcmp(action, "hum") == 0)
				humidity_set = atoi(value);
			else if (strcmp(action, "light") == 0)
				light_set = atoi(value);
			printf("[E5] 阈值更新 temp=%d hum=%d light=%d\n", temperature_set, humidity_set, light_set);
		}
		else if (strcmp(tok, "sleep") == 0 && action)
		{
			sleep_time = atoi(action);
			printf("[E5] 休眠时间设置 %d 分钟\n", sleep_time);
		}
		else if (strcmp(tok, "record") == 0 && action)
		{
			if (strcmp(action, "start") == 0)
			{
				request_record_audio("./web/recording.wav", record_seconds);
			}
			else if (strcmp(action, "play") == 0)
			{
				request_play_audio("./web/recording.wav");
			}
		}
		else if (strcmp(tok, "fanmode") == 0 && action)
		{
			mode_fan = atoi(action);  // 0手动 1自动
			printf("[E5] 风扇模式: %s\n", mode_fan ? "自动" : "手动");
		}
		else if (strcmp(tok, "display") == 0 && action)
		{
			int new_mode = atoi(action);
			if (new_mode >= 0 && new_mode <= 3)
			{
				mode_display = new_mode;
				printf("[E5] E1 显示模式: %d\n", mode_display);
			}
		}
		else if (strcmp(tok, "brightness") == 0 && action)
		{
			int val = atoi(action);
			if (val < 0) val = 0;
			if (val > 100) val = 100;
			lightness = val;
			update_e1_led(fd, list);  // 立即生效
			printf("[E5] RGB 亮度: %d%%\n", lightness);
		}
		else if (strcmp(tok, "lightmode") == 0 && action)
		{
			light_mode = atoi(action);  // 0手动 1自动
			printf("[E5] 灯光模式: %s\n", light_mode ? "自动" : "手动");
		}
	}

	fclose(fcmd);
	remove("./web/e5_command.txt");
}

// 智能联动控制
void smart_control(int fd, i2c_probe_target *list)
{
	// 自动风扇控制
	if (mode_fan == 1)
	{
		if (env.temperature > 28 || env.humidity > humidity_set || env.light_intensity > light_set)
		{
			if (!fan_off)
			{
				fan_off = 1;
				printf("[自动] 环境异常，开启风扇\n");
			}
			if (env.temperature > 32)
				dang_idx = 4;
			else if (env.temperature > 30)
				dang_idx = 3;
			else
				dang_idx = 2;
			e2_speed_control_all(fd, list, dang[dang_idx]);
		}
		else if (fan_off)
		{
			e2_speed_control_all(fd, list, 0);
			fan_off = 0;
			printf("[自动] 环境适宜，关闭风扇\n");
		}
	}
	// 自动调节E1亮度(基于光照)
	if(light_mode == 1){
		if (env.light_intensity < 100)
		{
			lightness = 20;
		}
		else if (env.light_intensity > 1000)
		{
			lightness = 100;
		}
		else
		{
			lightness = 20 + (int)((env.light_intensity - 100) * 80 / 900);
		}
	}
}

// 按键事件处理（长按/短按）
void handle_key_event(int fd, i2c_probe_target *list, int dev_idx, int key_num)
{
	if (key_idx < 0)
		return;
	// 长按
	if (s1_key[dev_idx].SW_long[key_num])
	{
		s1_key[dev_idx].SW_long[key_num] = false;
		printf("[长按] 按键 %d\n", key_num);
		switch (key_num)
		{
		case SW1:
			mode_set = !mode_set;
			printf("设置模式: %s\n", mode_set ? "开启" : "关闭");
			break;
		case SW2:
			voice_mode = !voice_mode;
			printf("语音控制: %s\n", voice_mode ? "开启" : "关闭");
			break;
		case SW3: // 休眠时间+
			if (sleep_time == 1)
				sleep_time = 3;
			else if (sleep_time == 3)
				sleep_time = 5;
			else if (sleep_time == 5)
				sleep_time = 10;
			printf("休眠时间: %d 分钟\n", sleep_time);
			break;
		case SW4: // 休眠时间-
			if (sleep_time == 10)
				sleep_time = 5;
			else if (sleep_time == 5)
				sleep_time = 3;
			else if (sleep_time == 3)
				sleep_time = 1;
			printf("休眠时间: %d 分钟\n", sleep_time);
			break;
		case SW5:
			temperature_set++;
			printf("温度阈值: %d ℃\n", temperature_set);
			break;
		case SW6:
			temperature_set--;
			printf("温度阈值: %d ℃\n", temperature_set);
			break;
		case SW7:
			humidity_set++;
			printf("湿度阈值: %d %%\n", humidity_set);
			break;
		case SW8:
			humidity_set--;
			printf("湿度阈值: %d %%\n", humidity_set);
			break;
		case SW9:
			light_set += 50;
			printf("光照阈值: %d lx\n", light_set);
			break;
		case SWA:
			light_set = (light_set >= 50) ? light_set - 50 : 0;
			printf("光照阈值: %d lx\n", light_set);
			break;
		case SWC:
			break;
		}
	}
	// 短按
	if (s1_key[dev_idx].SW_short[key_num])
	{
		s1_key[dev_idx].SW_short[key_num] = false;
		printf("[短按] 按键 %d\n", key_num);
		switch (key_num)
		{
		case SW1: // 风扇开/关
			if (fan_off)
			{
				e2_speed_control_all(fd, list, 0);
				fan_off = 0;
				printf("风扇关闭\n");
			}
			else
			{
				if (dang_idx == 0)
					dang_idx = 1; // 默认20%
				e2_speed_control_all(fd, list, dang[dang_idx]);
				fan_off = 1;
				printf("风扇开启 (档位: %d%%)\n", dang[dang_idx]);
			}
			break;
		case SW2: // 风扇档位切换(低->中->高->自动)
			if (mode_fan == 1)
			{
				mode_fan = 0;
				light_mode = 0;
				printf("风扇模式: 手动\n");
			}
			else
			{
				if(dang_idx==5){
					mode_fan = 1;
					printf("风扇模式: 自动\n");
					light_mode = 1;
					printf("灯光模式: 自动\n");
				}
				dang_idx = (dang_idx + 1) % 6;
				if (fan_off)
					e2_speed_control_all(fd, list, dang[dang_idx]);
				printf("风扇档位: %d%%\n", dang[dang_idx]);
			}
			break;
		case SW3: // E1显示模式切换
			mode_display = (mode_display + 1) % 4;
			printf("0为关闭,1为显示温度,2为显示湿度,3为显示光照\n");
			printf("显示模式: %d\n", mode_display);
			break;
		case SW4: // 场景模式切换
			mode_background = (mode_background + 1) % 4;
			printf("0为办公模式,1为学习模式,2为睡眠模式,3为娱乐模式\n");
			printf("场景模式: %d\n", mode_background);
			break;
		case SW5: // 亮度+
			if(light_mode==0){
				lightness += 10;
				if (lightness > 100)
					lightness = 100;
				printf("亮度: %d%%\n", lightness);
			}
			break;
		case SW6: // 亮度-
			if(light_mode==0){
				lightness -= 10;
				if (lightness < 0)
					lightness = 0;
				printf("亮度: %d%%\n", lightness);
			}
			break;
		case SW7: // 风扇转速+
			if (fan_off && dang_idx < 5)
			{
				dang_idx++;
				e2_speed_control_all(fd, list, dang[dang_idx]);
				printf("风扇档位: %d%%\n", dang[dang_idx]);
			}
			break;
		case SW8: // 风扇转速-
			if (fan_off && dang_idx > 0)
			{
				dang_idx--;
				e2_speed_control_all(fd, list, dang[dang_idx]);
				printf("风扇档位: %d%%\n", dang[dang_idx]);
			}
			break;
		case SW9: // 语音播报当前环境状态
		{
			char tbuf[256];
			snprintf(tbuf, sizeof(tbuf), "当前温度 %.1f 度，湿度 %.1f 百分比，光照 %.0f 勒克斯", env.temperature, env.humidity, env.light_intensity);
			tts_speak(tbuf);
		}
		break;
		case SWA: // 屏幕亮/灭
			if (mode_display == 0)
				mode_display = 1;
			else
				mode_display = 0;
			printf("屏幕%s\n", mode_display ? "亮起" : "熄灭");
			break;
		case SWC: // 系统重启
			// 调用安全重启函数
			system_reboot();
			break;
		}
	}
}

// ========== 主函数 ==========
int main()
{
	// 为 I2C 探测列表分配可修改的副本
	size_t list_size = sizeof(i2c_probe_target) * I2C_PROBE_LIST_LEN;
	i2c_probe_target *list = (i2c_probe_target *)malloc(list_size);
	if (!list)
	{
		perror("malloc failed");
		return -1;
	}
	memcpy(list, I2C_PROBE_LIST, list_size);

	printf("========================================\n");
	printf("  桌面智能管家系统 - 第一周任务\n");
	printf("  传感器与执行器驱动测试\n");
	printf("========================================\n\n");

	// 1. 探测所有I2C设备
	printf("[1/6] I2C设备探测中...\n");
	i2c_probe(list, I2C_PROBE_LIST_LEN);
	printf("探测完成\n\n");

	// 2. 查找各模块（若缺失会exit，请确保硬件齐全）
	printf("[2/6] 查找各模块...\n");
	I2c_s1_find(list);
	I2c_s2_find(list);
	I2c_s7_find(list);
	I2c_s8_find(list);
	I2c_e1_led_find(list);
	I2c_e1_tube_find(list);
	I2c_e2_find(list);
	printf("所有模块已找到\n\n");

	// 3. 打开I2C设备（使用S1所在总线）
	int fd = I2c_open(list[key_idx].path);
	if (fd < 0)
	{
		perror("打开I2C设备失败");
		free(list);
		return -1;
	}
	printf("I2C设备已打开，fd=%d\n\n", fd);

	// 4. 初始化各模块
	printf("[3/6] 初始化S1键盘...\n");
	I2c_s1_init_all(fd, list);
	printf("[4/6] 初始化E1数码管与RGB灯...\n");
	I2c_e1_tube_init_all(fd, list);
	I2c_e1_led_init_all(fd, list);
	printf("[5/6] 初始化E2风扇...\n");
	I2c_e2_init_all(fd, list);
	printf("[6/6] 初始化传感器...\n");
	I2c_s2_init_all(fd, list);
	I2c_s7_init_all(fd, list);
	// S8无需显式初始化
	printf("\n所有模块初始化完成！开始运行...\n\n");

	// 环境数据初始值
	memset(&env, 0, sizeof(env));
	env.temperature = 25.0;
	env.humidity = 50.0;
	env.light_intensity = 300.0;
	env.human_detected = 1;

	// 启动后台音频播放线程（用于 E4）
	if (pthread_create(&audio_thread_id, NULL, audio_thread, NULL) != 0)
	{
		perror("创建音频线程失败");
	}

	int loop_cnt = 0;
	int sht_delay = 0; // 用于控制SHT3x读取频率(每2秒一次)

	while (1)
	{
		loop_cnt++;
		sht_delay++;

		// 采集S8温湿度(每2秒一次，避免I2C过载)
		if (sht_delay >= 40)
		{ // 50ms * 40 = 2秒
			sht_delay = 0;
			if (sht_idx >= 0 && list[sht_idx].detected_count > 0)
			{
				s8_para sht = read_sht3x(fd, list[sht_idx].detected_addrs[0]);
				if (sht.temperature >= -45 && sht.temperature <= 125)
					env.temperature = sht.temperature;
				if (sht.humidity >= 0 && sht.humidity <= 100)
					env.humidity = sht.humidity;
			}
		}
		// 采集S2光照
		if (bright_idx >= 0 && list[bright_idx].detected_count > 0)
		{
			float lux = s2_read_bh1750_value(fd, list[bright_idx].detected_addrs[0]);
			if (lux >= 0 && lux < 100000)
				env.light_intensity = lux;
		}
		// 采集S7人体
		if (human_idx >= 0 && list[human_idx].detected_count > 0)
		{
			env.human_detected = I2c_human_detected(fd, list[human_idx].detected_addrs[0]);
		}
		env.timestamp = time(NULL);

		// 智能联动控制
		smart_control(fd, list);
		// 更新E1显示和LED
		update_e1_display(fd, list);
		update_e1_led(fd, list);
		// 同步到 E5 触控屏显示
		update_e5_display(fd, list);

		// 检查来自 E5 的命令文件（web/e5_command.txt）并处理
		process_e5_command(fd, list);

		// 按键处理（关键！）
		if (key_idx >= 0)
		{
			for (int i = 0; i < list[key_idx].detected_count; i++)
			{
				// 扫描按键状态（教师提供的函数）
				process_keys(fd, list[key_idx].detected_addrs[i], list);
				// 处理所有12个按键的事件
				for (int k = 1; k <= 12; k++)
				{
					handle_key_event(fd, list, i, k);
				}
			}
		}

		// 每100次循环(约5秒)打印一次状态
		if (loop_cnt % 100 == 0)
		{
			print_system_status();
		}

		// 提高响应速度：50ms 循环一次
		usleep(50000); // 50ms
	}

	I2c_close(fd);
	free(list);
	return 0;
}

// 安全重启：先 sync，再尝试 reboot syscall，失败时回退到 system("reboot")
void system_reboot(void)
{
	printf("开始重启系统...\n");
	fflush(stdout);
	sync();
	if (reboot(RB_AUTOBOOT) != 0)
	{
		perror("reboot syscall 失败，尝试使用 reboot 命令");
		int r = system("reboot");
		if (r == -1)
			perror("system reboot 失败");
	}
}

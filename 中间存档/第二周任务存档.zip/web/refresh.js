const tempEl = document.getElementById('temp');
const humEl = document.getElementById('hum');
const luxEl = document.getElementById('lux');
const humanEl = document.getElementById('human');
const fanEl = document.getElementById('fan');
const displayModeEl = document.getElementById('display_mode');
const alertSpan = document.getElementById('alert');
const voiceToggleBtn = document.getElementById('voice_toggle');
const speakStatusBtn = document.getElementById('speak_status');
const fanSpeedSlider = document.getElementById('fan_speed');
const fanSpeedVal = document.getElementById('fan_speed_val');
const brightnessSlider = document.getElementById('brightness_slider');
const brightnessVal = document.getElementById('brightness_val');
const fanModeBtn = document.getElementById('fan_mode_toggle');
const lightModeBtn = document.getElementById('light_mode_toggle');
const thTemp = document.getElementById('th_temp');
const thHum = document.getElementById('th_hum');
const thLight = document.getElementById('th_light');
const sleepInput = document.getElementById('sleep_time');
const rebootBtn = document.getElementById('reboot_btn');

let currentVoiceOn = true;
let currentFanMode = 0;   // 0手动,1自动
let currentLightMode = 0; // 0手动,1自动
let chart = null;

async function sendCommand(endpoint, payload) {
    try {
        const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!res.ok) console.error('命令失败', endpoint);
        setTimeout(fetchStatus, 300);
    } catch(e) { console.error(e); }
}

function initChart() {
    const ctx = document.getElementById('envChart').getContext('2d');
    chart = new Chart(ctx, {
        type: 'line',
        data: { labels: [], datasets: [
            { label: '温度 (°C)', data: [], borderColor: '#ff7c60', tension: 0.2, fill: false },
            { label: '湿度 (%)', data: [], borderColor: '#5eb3ff', tension: 0.2, fill: false },
            { label: '光照 (lx/10)', data: [], borderColor: '#f9d371', tension: 0.2, fill: false }
        ]},
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: { legend: { position: 'top', labels: { color: '#ccc' } } },
            scales: { y: { grid: { color: '#2a3a4a' }, ticks: { color: '#ddd' } },
                      x: { ticks: { color: '#aaa', autoSkip: true, maxTicksLimit: 6 } } }
        }
    });
}

function updateChart(history) {
    if (!chart) initChart();
    if (!history || !history.temp) return;
    chart.data.labels = Array(history.temp.length).fill('');
    chart.data.datasets[0].data = history.temp;
    chart.data.datasets[1].data = history.hum;
    chart.data.datasets[2].data = history.lux.map(v => v/10);
    chart.update();
}

async function fetchStatus() {
    try {
        const r = await fetch('e5_status.json?t='+Date.now());
        if (!r.ok) throw new Error();
        const data = await r.json();
        tempEl.textContent = data.temperature.toFixed(1)+'°C';
        humEl.textContent = data.humidity.toFixed(1)+'%';
        luxEl.textContent = data.light.toFixed(0)+'lx';
        humanEl.textContent = data.human ? '有人' : '无人';
        fanEl.textContent = data.fan_on ? data.fan_level+'%' : '关闭';
        const modes = ['关闭', '温度', '湿度', '光照'];
        displayModeEl.textContent = modes[data.display_mode] || '--';
        alertSpan.textContent = data.alert || '环境正常';
        currentVoiceOn = !!data.voice_on;
        voiceToggleBtn.textContent = currentVoiceOn ? ' 语音播报 开' : ' 语音播报 关';
        currentFanMode = data.fan_mode ?? 0;
        fanModeBtn.textContent = currentFanMode ? '风扇模式: 自动' : '风扇模式: 手动';
        currentLightMode = data.light_mode ?? 0;
        lightModeBtn.textContent = currentLightMode ? '灯光模式: 自动' : '灯光模式: 手动';
        thTemp.value = data.temperature_set ?? 28;
        thHum.value = data.humidity_set ?? 60;
        thLight.value = data.light_set ?? 300;
        sleepInput.value = data.sleep_time ?? 1;
        brightnessSlider.value = data.brightness ?? 50;
        brightnessVal.textContent = brightnessSlider.value;
        fanSpeedSlider.value = data.fan_level ?? 20;
        fanSpeedVal.textContent = fanSpeedSlider.value;
        if (data.history) updateChart(data.history);
    } catch(e) {
        alertSpan.textContent = '⚠️ 无法连接至智能管家';
    }
}

fetchStatus();
setInterval(fetchStatus, 800);

// 风扇控制
document.getElementById('fan_on').onclick = () => sendCommand('/api/fan', { action: 'on', speed: parseInt(fanSpeedSlider.value) });
document.getElementById('fan_off').onclick = () => sendCommand('/api/fan', { action: 'off' });
document.getElementById('fan_set').onclick = () => sendCommand('/api/fan', { action: 'set', speed: parseInt(fanSpeedSlider.value) });
document.getElementById('fan_speed_up').onclick = () => {
    let v = parseInt(fanSpeedSlider.value) + 20;
    if (v > 100) v = 100;
    fanSpeedSlider.value = v;
    fanSpeedVal.textContent = v;
    sendCommand('/api/fan', { action: 'set', speed: v });
};
document.getElementById('fan_speed_down').onclick = () => {
    let v = parseInt(fanSpeedSlider.value) - 20;
    if (v < 0) v = 0;
    fanSpeedSlider.value = v;
    fanSpeedVal.textContent = v;
    sendCommand('/api/fan', { action: 'set', speed: v });
};
fanModeBtn.onclick = () => sendCommand('/api/fanmode', { mode: currentFanMode ? 0 : 1 });

// E1 显示模式
document.querySelectorAll('[data-display]').forEach(btn => {
    btn.onclick = () => sendCommand('/api/display', { mode: parseInt(btn.dataset.display) });
});
// 屏幕亮/灭：显示模式切换 0 <-> 1
document.getElementById('screen_toggle').onclick = () => {
    const currentMode = parseInt(displayModeEl.textContent === '关闭' ? 0 : (displayModeEl.textContent === '温度' ? 1 : (displayModeEl.textContent === '湿度' ? 2 : 3)));
    const newMode = (currentMode === 0) ? 1 : 0;
    sendCommand('/api/display', { mode: newMode });
};

// 亮度控制（手动模式下有效，自动模式下命令也可用，但会被自动覆盖）
brightnessSlider.oninput = () => brightnessVal.textContent = brightnessSlider.value;
document.getElementById('brightness_set').onclick = () => sendCommand('/api/brightness', { brightness: parseInt(brightnessSlider.value) });
document.getElementById('brightness_up').onclick = () => {
    let v = parseInt(brightnessSlider.value) + 20;
    if (v > 100) v = 100;
    brightnessSlider.value = v;
    brightnessVal.textContent = v;
    sendCommand('/api/brightness', { brightness: v });
};
document.getElementById('brightness_down').onclick = () => {
    let v = parseInt(brightnessSlider.value) - 20;
    if (v < 0) v = 0;
    brightnessSlider.value = v;
    brightnessVal.textContent = v;
    sendCommand('/api/brightness', { brightness: v });
};
// 灯光模式切换
lightModeBtn.onclick = () => sendCommand('/api/lightmode', { mode: currentLightMode ? 0 : 1 });

// 场景模式
document.querySelectorAll('[data-scene]').forEach(btn => {
    btn.onclick = () => sendCommand('/api/scene', { scene: parseInt(btn.dataset.scene) });
});

// 语音
voiceToggleBtn.onclick = () => sendCommand('/api/voice', { action: currentVoiceOn ? 'off' : 'on' });
speakStatusBtn.onclick = () => sendCommand('/api/speak_status', {});

// 阈值与休眠
document.getElementById('set_temp').onclick = () => sendCommand('/api/threshold', { type: 'temp', value: parseInt(thTemp.value) });
document.getElementById('set_hum').onclick = () => sendCommand('/api/threshold', { type: 'hum', value: parseInt(thHum.value) });
document.getElementById('set_light').onclick = () => sendCommand('/api/threshold', { type: 'light', value: parseInt(thLight.value) });
document.getElementById('set_sleep').onclick = () => sendCommand('/api/sleep', { minutes: parseInt(sleepInput.value) });
rebootBtn.onclick = () => sendCommand('/api/reboot', {});